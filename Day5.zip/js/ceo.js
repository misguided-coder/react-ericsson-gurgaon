	(function () {
		function CEO() {
			this.name = "Bill Gates";
			this.phone = "9800000000";
	
			this.show = function() {
				document.write("NAME : "+this.name)
				document.write("<br/>")
				document.write("PHONE : "+this.phone)
				document.write("<br/>")
				document.write("===================================")
				document.write("<br/>")
			}
		
		}

		if(typeof window.ceo === 'undefined') {
			ceo = new CEO();
			console.log("CEO is initialized!!")
		}
	})();

