var calc = {
	add : function (arg1,arg2) {
		document.write("SUM : "+(arg1+arg2));
		document.write("<br/>");
	},
	subtract : function (arg1,arg2) {
		document.write("DIFF : "+(arg1-arg2));
		document.write("<br/>");
	}
};