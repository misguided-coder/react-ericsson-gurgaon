var calc = (function(calc) {

	calc.add = function (arg1,arg2) {
		document.write("SUM : "+(arg1+arg2));
		document.write("<br/>");
	},
	calc.subtract = function (arg1,arg2) {
		document.write("DIFF : "+(arg1-arg2));
		document.write("<br/>");
	}
	
	return calc;
})(calc || {});



