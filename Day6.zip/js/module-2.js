var calc = (function(calc) {

	calc.multiply = function (arg1,arg2) {
		document.write("MULTIPLY : "+(arg1*arg2));
		document.write("<br/>");
	}
	
	calc.divide = function (arg1,arg2) {
		document.write("DIVIDE : "+(arg1/arg2));
		document.write("<br/>");
	}
	
	return calc;
})(calc || {});



