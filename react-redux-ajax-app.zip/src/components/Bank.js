import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import Customer from './Customer';

export default class Bank extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Bank constructor!!!!");
	}

	render() {
		return (<div className='Bank'>
				<header>
					<h2>Core Banking App</h2>
				</header>
				<Customer />
			</div>);
	}
}

