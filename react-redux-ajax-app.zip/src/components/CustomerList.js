import React,{Component} from 'react';

export default class CustomerList extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Customer constructor!!!!");
		this.state = {
			customers : [],
			errorMessage : ''
		};
	}

	render() {
		return (<div>
				<h1>Customer List</h1>
				<h2>{this.state.errorMessage}</h2>
				<table>
					<tbody>
						{
							this.state.customers.map((customer,idx) => { return <tr key={'Row'+idx}>
								<td>{customer.id}</td>
								<td>{customer.name}</td>
								<td>{customer.balance}</td>
								<td>{customer.type}</td>
								<td>{customer.address.city}</td>
							</tr> })
						}	
					</tbody>
				</table>
			</div>);
	}


	componentDidMount()  {

		fetch('http://localhost:3000/data/customers.json')
		.then((res) => { 
			return res.json();
		})
		.then((data)=> {
			console.log(data);
			this.setState({customers:data});
		});			
	}
	
}

