import React,{Component} from 'react';
import {connect} from 'react-redux';
import {Actions} from '../actions';

class Customer extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Customer constructor!!!!");
		this.deposit = this.deposit.bind(this);
		this.withdraw = this.withdraw.bind(this);
	}

	deposit() {
		this.props.depositMoney(parseInt(this.refs.balTxt.value));		
	}

	withdraw() {
		this.props.withdrawMoney(parseInt(this.refs.balTxt.value));		
	}
	
	render() {
		return (<div>
				<h1>Account Holder Details</h1>
				<section>
					<h4>Name : {this.props.name}</h4>
					<h4>Balance : {this.props.balance}</h4>
					<hr/>
					Enter Amount : <input type='text' defaultValue='100000.00' ref='balTxt' /><br/><br/>
					<button onClick={this.deposit}>Deposit</button>
					<button onClick={this.withdraw}>Withdraw</button>
				</section>
			</div>);
	}
}

const mapStateToProps = state => {
	return {
		name : state.name,
		balance : state.balance
	};
}


const mapDispachToProps = dispatch => {
	return {
		depositMoney :  (amount) => dispatch({type:Actions.DEPOSIT,amount : amount}),
		withdrawMoney : (amount) => dispatch({type:Actions.WITHDRAW,amount : amount})
	};
}

export default connect(mapStateToProps,mapDispachToProps)(Customer);




