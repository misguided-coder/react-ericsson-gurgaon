import React,{Component} from 'react';
//import Bank from './components/Bank';
import CustomerList from './components/CustomerList';

export default class App extends Component {

	constructor(props) {
		super(props);
		console.log("Inside App constructor!!!!");
	}

	render() {
		return (<div className='App'>
				<h1>Core Banking App</h1>
				<CustomerList />
			</div>);
	}
}

