import {Actions} from '../actions';

const initialState = {
	name : "Jaggu",
	balance : 1000.00
};

const appReducer = (state = initialState,action)  => {
	
	var newState = {...state}; 
	
	if(action.type === Actions.DEPOSIT) {
		newState.balance += action.amount;
	}	

	if(action.type === Actions.WITHDRAW) {
		newState.balance -= action.amount;
	}	

	return newState;
};

export default appReducer;