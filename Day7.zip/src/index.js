import React from 'react';
import ReactDOM from 'react-dom';
import Course from './Course';

ReactDOM.render(<Course />,document.getElementById('app'));
