import React from 'react';

export default class Cool extends React.Component {
	
	render() {
		return <h1>Super Cool Component</h1>
	}
}



