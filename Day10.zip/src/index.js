import React from 'react';
import ReactDOM from 'react-dom';
import Population from './Population';

ReactDOM.render(<Population />, document.getElementById('app'));

