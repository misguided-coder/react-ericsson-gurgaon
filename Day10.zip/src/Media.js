import React,{Component} from 'react';

import Movie from './Movie';
import Song from './Song';
import Holiday from './Holiday';


export default class Media extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Media constructor!!!!");
		this.updateMovies = this.updateMovies.bind(this);
		this.state = {
			destinations : ['Dubai','Singapore','Malaysia','Abu Dhabi','GOA'],
			movies : ['Don','DDLJ','Shool','Robot'],
			songs : ['Song 1','Song 2','Song 3','Song 4','Song 5']
		};
	}

	updateMovies(movieName) {
		console.log("Inside Media updateMovies()!!!!");
		//this.state.movies.push(movieName); 
		//this.forceUpdate();

		this.setState({movies : [...this.state.movies,movieName]});
	}

	render() {
		return (<div>
				<h1>{this.props.title}</h1>
				<Movie title='Movie Details' update={this.updateMovies} movieList={this.state.movies} />
				<Song title='Song Details' songList={this.state.songs} />		
				<h1>Wonderful Holiday Destinations</h1>
				{
					this.state.destinations.map((value,idx)=> <Holiday key={'Holiday-'+idx} destination={value} />)
				}
				
			</div>);
	}
}

