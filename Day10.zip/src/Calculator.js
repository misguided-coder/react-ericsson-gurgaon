import React,{Component} from 'react';

export default class Calculator extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Calculator constructor!!!!");
		this.state = {
			arg1 : 10,
			arg2 : 10,
			result : 20
		};

		this.doSum = this.doSum.bind(this);
		this.doDiff = this.doDiff.bind(this);
	}

	doSum(event) {
		console.log("Inside doSum()!!!!");
		event.preventDefault();

		this.state.arg1 = parseInt(this.refs.arg1.value);
		this.state.arg2 = parseInt(this.refs.arg2.value);

		this.setState({result : this.state.arg1 + this.state.arg2});

	}

	doDiff(event) {
		console.log("Inside doDiff()!!!!");
		event.preventDefault();

		this.state.arg1 = parseInt(this.refs.arg1.value);
		this.state.arg2 = parseInt(this.refs.arg2.value);

		this.setState({result : this.state.arg1 - this.state.arg2});

	}

	render() {
		return (<div>
				<h1>Simple Math Calculator</h1>
				<form>
					<label htmlFor='arg1'>Number : </label>
					<input  type='number' min='10' max='50'  ref='arg1' name='arg1' defaultValue={this.state.arg1} /><br/>	
					<label htmlFor='arg1'>Number : </label>
					<input type='number' min='10' max='50' ref='arg2' name='arg2' defaultValue={this.state.arg2} /><br/>
					<h3>Result : {this.state.result}</h3>	
					<button onClick={this.doSum}>SUM</button>
					<button onClick={this.doDiff}>DIFF</button>
				</form>
			</div>);
	}
}

