//React specific imports
import React,{Component} from 'react';

//Application specific imports
import Weather from './Weather';
import Cricket from './Cricket';
import News from './News';

const array = [
		'Big Train accident happened last night.',
		'Delhi is most polluted city in the world.',
		'Delhi is not a place to live.'
	];

export default class App extends Component {

	constructor(props) {
		super(props);
		console.log("Inside App constructor!!!!");
	}

	render() {
		return (<div>
				<h1>Entertainment App</h1>
				<Weather summary='Weather is cool outside.' />
				<Cricket />
				<News summary={array[0]} />
				<News summary={array[1]} />
				<News summary={array[2]} />
			</div>);
	}
}

