import React,{Component} from 'react';

export default class Population extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Population constructor!!!!");
		this.state = {
			city : '',
			currentPopulation : '',
			values : {
				pune : 1200000,
				delhi : 5600000,
				mumbai : 99900000,
				goa : 400000
			}
		};

		this.cityChanged = this.cityChanged.bind(this);
	}

	cityChanged(event) {
		console.log("Inside cityChanged()!!!!");
		event.preventDefault();		
		var localCity = event.target.value;
			
		//this.refs.region0.innerHTML = this.state.values[localCity.toLowerCase()];
		this.setState({city : localCity ,currentPopulation : this.state.values[localCity.toLowerCase()]})
	}

	render() {

		var population = '';

		if(this.state.currentPopulation) {
			population = <h3>Population : 
						<span ref='region0'>{this.state.currentPopulation}</span>
				</h3>;
		}

		return (<div>
				<h1>Population Teller</h1>
				<select value={this.state.city} onChange={this.cityChanged}>
					<option value=''>--Select City--</option>
					<option value='Delhi'>Delhi</option>
					<option value='Pune'>Pune</option>
					<option value='Mumbai'>Mumbai</option>
					<option value='GOA'>GOA</option>
				</select>
				{population}
			</div>);
	}
}

