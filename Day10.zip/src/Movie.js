import React,{Component} from 'react';

export default class Movie extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Movie constructor!!!!");
		this.addMovie = this.addMovie.bind(this);
	}

	addMovie() {
		this.props.update('Dangal');
		console.log("New Movie added!!!!");
	}

	render() {
		return (<div>
				<h1>{this.props.title}</h1>
				<section>
					<ul>
						{

							this.props.movieList.map((value,idx) => { 
									return (<h3 key={'Movie-'+idx}>
										<li>{value}</li> 
									</h3>);
							})
						}
					</ul>
					<button onClick={this.addMovie}>Add Movie</button>
				</section>
			</div>);
	}
}

