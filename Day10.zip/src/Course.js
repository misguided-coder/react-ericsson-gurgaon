import React from 'react';

import './Course.css';

export default class Course extends React.Component {

	constructor(props) {
		super(props);
		console.log("Inside Course constructor!!!!");
		this.state = {
			title : 'React Cookbook',
			duration :  4,
			price : 150
		};
		this.updatePrice = this.updatePrice.bind(this);
	}
	

	sell() {
		console.log("Inside Course sell!!!!!");
	}

	updatePrice() {
		console.log("Inside Course updatePrice!!!!!");
		console.log(`Before Price : ${this.state.price}`);
		//this.state.price  = 5000000;
		this.setState({price :5000000,duration:10});
		console.log(`After Price : ${this.state.price}`);
		//this.forceUpdate();
	}

	render() {
		return (<div className='container'>
				<h1 className='header'>Course Details</h1>
				<section className='content'>
					<h2>Name : <span>{this.state.title}</span></h2>
					<h2>Duration : <span>{this.state.duration}</span></h2>
					<h2>Price : <span>{this.state.price}</span></h2>
					<button onClick={this.sell}>Sell</button>
					<button onClick={this.updatePrice}>Update Price</button>
				</section>
			</div>);
	}
}

