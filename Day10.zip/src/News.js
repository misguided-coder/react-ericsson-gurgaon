import React,{Component} from 'react';

export default class News extends Component {

	constructor(props) {
		super(props);
		console.log("Inside News constructor!!!!");
	}

	render() {
		return (<div>
				<h1>Breaking News</h1>
				<section>
					<h2>{this.props.summary}</h2>
				</section>
			</div>);
	}
}

