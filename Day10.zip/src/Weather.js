import React,{Component} from 'react';

export default class Weather extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Weather constructor!!!!");
		this.state = {
			summary : props.summary
		};

		this.updateWeather = this.updateWeather.bind(this);
	}

	updateWeather () {
		console.log("Inside updateWeather()!!!!");
		this.setState({summary : `Todays weather is ${Math.floor(Math.random()*30)} degree temp outside.`}); 
	}

	render() {
		return (<div>
				<h1>Todays Weather</h1>
				<section>
					<h4>{this.state.summary}</h4>
					<button onClick={this.updateWeather}>Update</button>
				</section>
			</div>);
	}
}

