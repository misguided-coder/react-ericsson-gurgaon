import React from 'react';

const Car = (props) => {
	return 	(<div>
			<h1>Audi Q7 price is {props.price}.</h1>
		</div>);
};

export default Car;