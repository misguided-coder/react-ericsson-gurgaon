import React,{Component} from 'react';
import PersonList from './PersonList';

export default class App extends Component {

	constructor(props) {
		super(props);
		console.log("Inside App constructor!!!!");
	}

	render() {
		return (<div>
				<h1>Hello App</h1>		
				<PersonList />
			</div>);
	}
}

