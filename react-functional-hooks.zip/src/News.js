import React from 'react';

var News = function () {
	return <h1>Today is Friday.</h1>;
}

export default News;
