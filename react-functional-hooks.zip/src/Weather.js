import React from 'react';

//function Weather ({city,day,month}) {
const Weather = ({city,day,month}) => {
	return <h1>Weather of {city} on {day} day in {month} month is Cool.</h1>;
}

export default Weather;
