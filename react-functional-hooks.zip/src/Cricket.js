import React from 'react';

const Cricket = () => {
	return 	(<div>
			<h1>Cricket is a good business.</h1>
		</div>);
};

export default Cricket;
