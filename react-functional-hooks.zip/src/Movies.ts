import React from 'react';

interface Cinema {
	watchMovie()
}

class Movies extends Component implements Cinema {

	constructor() {
		this.state = {
			name :string = 'Mohan'
		};
	}

	watchMovie() {

	}

	render() {
		return <h1>Lets watch DDLJ</h1>;
	}
}

export default Movies;
