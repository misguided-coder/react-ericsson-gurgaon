import React, {useState,useEffect} from 'react';
import axios from 'axios';

const PersonList = () => {

	let [persons,modifyPersons] = useState([]);

	const getDataFromServer = async () => {
		console.log("Inside getDataFromServer callback!!!!");
		let res = await axios.get('http://localhost:3000/data/customers.json')
		modifyPersons([...res.data]);
		
		/*axios.get('http://localhost:3000/data/customers.json')
		.then((res) => { 
			modifyPersons([...res.data]);
		});*/
	};
	
	useEffect(()=>{
		console.log("Inside useEffect callback!!!!");
		/*fetch('http://localhost:3000/data/customers.json')
		.then((res) => { 
			return res.json();
		}).then((data)=> {
			console.log(data);
			modifyPersons([...data]);
		});*/		
	},[]);

	return 	(<div>
		<h1>Person List</h1>
		<table>
			<tbody>
			{
				persons.map((person,idx) => {
					return <tr key={'p'+idx}>
						<td>{person.id}</td>
						<td>{person.name}</td>
						<td>{person.balance}</td>
					</tr>
				})
			}
			</tbody>
		</table>
		<button onClick={getDataFromServer}>Load Data</button>
		</div>);
};

export default PersonList;