import React, {useState,useEffect} from 'react';

const Person = () => {

	let initialAge = 12;
	let [name,changeName] = useState('Jaggu');
	let [age,changeAge] = useState(initialAge);

	const handleAge = () => {
		changeAge((currentAge) => {
			var salt = 100
			return currentAge + salt
		});
	};
	
	useEffect(()=>{
		console.log("Inside useEffect callback!!!!");
		//changeAge(200);
	},[age]);

	return 	(<div>
			<h1>Person Details</h1>
			<p>Name : {name}</p>
			<p>Age : {age}</p>
			<button onClick={handleAge}>Change Age</button>
			<button onClick={()=>{ changeName('Pintu') }}>Change Name</button>
		</div>);
};

export default Person;