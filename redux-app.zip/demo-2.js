var redux = require('redux');

var initialData = {
	balance : 1000.00
};

function reducer(data = initialData,action) {
		
	var newState = {...data};

	if(action.type === 'DEPOSIT') {
		newState.balance = newState.balance + action.amount; 	
	}

	if(action.type === 'WITHDRAW') {
		newState.balance = newState.balance - action.amount; 	
	}

	return newState;
}

var store = redux.createStore(reducer);

//Views will be always subscribers

store.subscribe(() => {
	console.log(JSON.stringify(store.getState()) +" displayed in Pie Chart.")
});

store.subscribe(() => {
	console.log(JSON.stringify(store.getState()) +" displayed in Bar Chart.")
});

store.subscribe(() => {
	console.log(JSON.stringify(store.getState()) +" displayed in Tabular Form.")
});

store.subscribe(() => {
	console.log(JSON.stringify(store.getState()) +" displayed in Tabbed View.")
});

function depositMoney(amount) {
	return { type:'DEPOSIT',amount:amount };
}

function withdrawMoney(amount) {
	return {type:'WITHDRAW',amount:amount};

}

store.dispatch(depositMoney(100.00));
store.dispatch(withdrawMoney(500.00));

