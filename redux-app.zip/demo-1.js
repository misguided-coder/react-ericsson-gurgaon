var redux = require('redux');

var initialData = {
	balance : 1000.00
};

function reducer(data = initialData,action) {
		
	var newState = {...data};

	if(action.type === 'DEPOSIT') {
		newState.balance = newState.balance + 500.00; 	
	}

	if(action.type === 'WITHDRAW') {
		newState.balance = newState.balance - 500.00; 	
	}

	return newState;
}


var store = redux.createStore(reducer);

var action1 = {type:'DEPOSIT'};
var action2 = {type:'WITHDRAW'};

store.dispatch(action1);
store.dispatch(action2);


