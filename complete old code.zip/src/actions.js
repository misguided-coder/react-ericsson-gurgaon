export const Actions = { 
	WITHDRAW : 'Withdraw',
	DEPOSIT : 'Deposit'
};