import React,{Component} from 'react';
import {createStore} from 'redux';
import {Provider} from 'react-redux';

import {Customer} from './Customer';

const Actions = { 
	WITHDRAW : 'Withdraw',
	DEPOSIT : 'Deposit'
};

const initialState = {
	name : "Jaggu",
	balance : 1000.00
};

function appReducer(state = initialState,action) {
	
	var newState = {...state}; 
	
	if(action.type === Actions.DEPOSIT) {
		newState.balance += action.amount;
	}	

	if(action.type === Actions.WITHDRAW) {
		newState.balance -= action.amount;
	}	

	return newState;
}

var store = createStore(appReducer);

export default class Bank extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Bank constructor!!!!");
	}

	render() {
		return (<Provider store={store}>
				<div>
					<h1>Core Banking App</h1>
					<Customer />
				</div>
			</Provider>
		);
	}
}
