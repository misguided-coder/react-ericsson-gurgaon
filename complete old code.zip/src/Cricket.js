import React,{Component} from 'react';

export default class Cricket extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Cricket constructor!!!!");
	}

	render() {
		return (<div>
				<h1>Crickt Info</h1>
				<section>
					<h2>Tomorrow we have 20:20 between India and Australia.</h2>
				</section>
			</div>);
	}
}

