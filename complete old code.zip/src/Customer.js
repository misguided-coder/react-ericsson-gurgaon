import React,{Component} from 'react';
import {connect} from 'react-redux';
import {Actions} from './actions';

class Customer extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Customer constructor!!!!");
	}

	render() {
		return (<div>
				<h1>Account Holder Details</h1>
				<section>
					<h4>Name : {this.props.name}</h4>
					<h4>Balance : {this.props.balance}</h4>
					<hr/>
					<button onClick={this.props.depositMoney}>Deposit</button>
					<button onClick={this.props.withdrawMoney}>Withdraw</button>
				</section>
			</div>);
	}
}

const mapStateToProps = state => {
	return {
		name : state.name,
		balance : state.balance
	};
}


const mapDispachToProps = dispatch => {
	return {
		depositMoney :  () => dispatch({type:Actions.DEPOSIT,amount : 1000.00}),
		withdrawMoney : () => dispatch({type:Actions.WITHDRAW,amount : 1000.00})
	};
}

export default connect(mapStateToProps,mapDispachToProps)(Customer);




