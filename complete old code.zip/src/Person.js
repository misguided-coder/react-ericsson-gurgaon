import React,{Component} from 'react';

export default class Person extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Person constructor!!!!");
		this.state = {
			name : "Jaggu"
		};
	}

	static getDerivedStateFromProps(props) {
		console.log("Inside Person getDerivedStateFromProps()!!!!");
		//return { name : "Pintu" };	
		//return { name : "Mr . "+props.personName};
		return null;
	}

	render() {
		console.log("Inside Person render!!!!!");

		return (<div>
				<h1>Person Details</h1>
				<p>Name  : {this.state.name}</p>
			</div>);
	}

	componentDidMount() {
		console.log("Inside Person componentDidMount()!!!!");
		setTimeout(() =>{
			this.setState({name : "Ritesh"});		
		},5000);
	}

	shouldComponentUpdate() {
		console.log("Inside Person shouldComponentUpdate()!!!!");
		return false;
	}

	getSnapshotBeforeUpdate(prevState,prevProps) {
		console.log("Inside Person getSnapshotBeforeUpdate()!!!!");
		console.log(prevState);
		console.log(prevProps);
		return {name : "Raj"};
	}

	componentDidUpdate() {
		console.log("Inside Person componentDidUpdate()!!!!");
	}	
	
	componentWillUnmount() {
		console.log("Inside Person componentWillUnmount()!!!!");
	}
}

