import {createStore} from 'redux';
import {Actions} from '../actions';

const initialState = {
	name : "Jaggu",
	balance : 1000.00
};

function appReducer(state = initialState,action) {
	
	var newState = {...state}; 
	
	if(action.type === Actions.DEPOSIT) {
		newState.balance += action.amount;
	}	

	if(action.type === Actions.WITHDRAW) {
		newState.balance -= action.amount;
	}	

	return newState;
}

const store = createStore(appReducer);

export default store;

