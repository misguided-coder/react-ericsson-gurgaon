import React,{Component} from 'react';

export default class Song extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Song constructor!!!!");
	}

	render() {
		return (<div>
				<h1>{this.props.title}</h1>
				<section>
					<ul>
					{

							this.props.songList.map((value,idx)=> <li key={'Song-'+idx}>{value}</li>)
					}
					</ul>
				</section>
			</div>);
	}
}

