import React from 'react';
import PropTypes from 'prop-types';

export default class Car extends React.Component {
	
	render() {
		return (<div>
				<h1>Luxury Car</h1>
				<h2>Name : {this.props.model}</h2>
				<h2>Color : {this.props.color}</h2>
				<h2>Price : {this.props.price}</h2>
			</div>);
	}
}


Car.defaultProps = {
	model : "Merc CLA",
	color : "Tomato",
	price : 780000000.00
}; 

Car.propTypes = {
	model : PropTypes.string,
	color : PropTypes.string,
	price : PropTypes.number
}; 




