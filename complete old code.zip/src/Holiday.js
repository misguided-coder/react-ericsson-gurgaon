import React,{Component} from 'react';

export default class Holiday extends Component {

	constructor(props) {
		super(props);
		console.log("Inside Holiday constructor!!!!");
	}

	render() {
		return 	<p>{this.props.destination}</p>;
	}
}

